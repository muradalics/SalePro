<h1>Hey {{$name}}!</h1>
<h3>A GiftCard has successfully created for You. Card no: {{$card_no}}.</h3>
<p>Your current balance is: {{$amount}}</p>
<p>GiftCard expired date is: {{$expired_date}}</p>
<p>Thank you</p>